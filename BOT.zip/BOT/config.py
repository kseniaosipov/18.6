TOKEN = '5275640666:AAEGmUG0Q4yjv4TR3egxIqQOrfZc_DZCG9g'

keys = {
    'рубль': 'RUB',
    'доллар': 'USD',
    'евро': 'EUR'
}
